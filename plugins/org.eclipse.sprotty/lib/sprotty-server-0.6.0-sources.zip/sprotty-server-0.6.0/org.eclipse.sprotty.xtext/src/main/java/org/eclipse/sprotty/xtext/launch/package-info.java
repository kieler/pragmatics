/**
 * Classes for launching a diagram language server.
 */
package org.eclipse.sprotty.xtext.launch;