/**
 * Classes that support Sprotty functionality to Xtext based languages
 * 
 * All classes in this package are instantiated by the language specific 
 * injector. 
 */
package org.eclipse.sprotty.xtext;